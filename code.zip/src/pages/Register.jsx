import React from 'react';

const Register = () => (
  <div style={{ maxWidth: 350, margin: '2rem auto' }}>
    <h2>Register</h2>
    <p>Registration is not yet implemented.</p>
    {/* You can add registration logic here */}
  </div>
);

export default Register;