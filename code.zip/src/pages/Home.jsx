import React from 'react';

const Home = () => (
  <div>
    <h1>Welcome to Mbogiwood</h1>
    <p>
      {/* TODO: Replace with actual content from mbogisite.pdf */}
      This homepage will display the core introduction and sections from the provided PDF.
    </p>
  </div>
);

export default Home;